const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const User = require('../models/User')

router.get('/register', (req, res) => {
  res.render('register');
});

router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/register', async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const role = req.body.username === 'admin' ? 'admin' : 'regular';
    const user = new User({
      username: req.body.username,
      password: hashedPassword,
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      age: req.body.age,
     
      role: role
    });

    const result = await user.save();
    res.redirect('/login'); 
  } catch (error) {
    if (error.code === 11000) { 
      return res.status(400).send("Username already exists. Please choose another username.");
    }
    console.error(error);
    res.redirect('/register');
  }
});

  
  router.post('/login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const user = await User.findOne({ username: username });
      if (user) {
        const isValid = await bcrypt.compare(password, user.password);
        if (isValid) {
          req.session.userId = user._id;
          res.redirect('/my-profile');
        } else {
          res.send('Invalid username or password');
        }
      } else {
        res.send('Invalid username or password');
      }
    } catch (error) {
      console.error(error);
      res.redirect('/login');
    }
  });

  router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Error destroying session:', err);
        return res.status(500).send('Could not log out. Please try again.');
      }
  
      res.redirect('/login'); 
    });
  });
  
  

module.exports = router;