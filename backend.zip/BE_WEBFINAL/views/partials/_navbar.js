<nav>
<div class="logo"> <h1 style="font-size: 20px;"> Balkhash </h1> </div>
<div class="menu">
  <a class="nav-link" href="/">Home </a>
  <a class="nav-link" href="/admin">Admin Panel</a>
  <a class="nav-link" href="/my-profile">Profile</a>
  <a class="nav-link" href="/logout">Logout</a>
</div>
</nav>
