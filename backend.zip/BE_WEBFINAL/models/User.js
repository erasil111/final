const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  password: String,
  firstName: String,
  lastName: String,
  age: Number,
  
  creationDate: { type: Date, default: Date.now },
  role: {
    type: String,
    default: 'regular', 
    enum: ['admin', 'regular'] 
  }
});

module.exports = mongoose.model('User', userSchema);
